<?php

namespace App\Http\Controllers\API;

use App\Parroquia;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class ParroquiaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $parroquias = Parroquia::join('ciudades', 'ciudades.ciudad_id', '=', 'parroquias.ciudad_id')
            ->selectRaw('parroquias.*, ciudades.nombre as ciudad')
            ->orderBy('parroquias.parroquia_id', 'desc')
            ->paginate(10);
        return response()->json($parroquias, 200);
    }
    public function listar()
    {
        $parroquia = Parroquia::join('ciudades', 'ciudades.ciudad_id', '=', 'parroquias.ciudad_id')
            ->selectRaw('parroquias.*, ciudades.nombre as ciudad')
            ->orderBy('parroquias.parroquia_id', 'desc')
            ->get();
        return response()->json($parroquia, 200);
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        return response()->json(Parroquia::create($request->all()), 200);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return response()->json(Parroquia::find($id), 200);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $parroquia = Parroquia::find($id);
        $parroquia->update($request->all());
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $parroquia = Parroquia::find($id);
        $parroquia->delete();
        return response()->json($parroquia, 200);
    }
}
